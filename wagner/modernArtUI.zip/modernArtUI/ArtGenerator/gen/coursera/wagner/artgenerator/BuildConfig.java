/** Automatically generated file. DO NOT MODIFY */
package coursera.wagner.artgenerator;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}